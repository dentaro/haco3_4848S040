x=80
y=64
tx=0
ty=0
ax=171--lcx(171)
ay=200--lcy(218)
wx=156--0
wy=187--36
px=0
py=0
wstat=1

function lcx(tx)
  return (tx-wx+10)*8
end

function lcy(ty)
  return (ty-wy+8)*8
end


function input()
  if btn(1) >= 1 then wx = wx-1 end
  if btn(2) >= 1 then wx = wx+1 end
  if btn(3) >= 1 then wy = wy-1 end
  if btn(4) >= 1 then wy = wy+1 end
  -- if btnp(1) then wx = wx-1 end
  -- if btnp(2) then wx = wx+1 end
  -- if btnp(3) then wy = wy-1 end
  -- if btnp(4) then wy = wy+1 end
end

function _init()--1回だけ
  -- pal(0)
  -- music(0,64,120)--サウンド0番を任意のボリューム0~255で鳴らす,テンポを決める（入れないとデフォルト１００)
end
function _update()
  input()
  wx = wx%256
  wy = wy%256
end
function _draw()
  rmap("/init/param/map/w.bin",wx,wy)
  spr8(64,x,y,1,1,0, 0,10)--主人公スプライト透明色指定のあとに色番号をつけるとふちどり

  --城を置く
  spr8(47, lcx(172),lcy(210), 1,1,0, 0)
  spr8(48, lcx(173),lcy(210), 1,1,0, 0)
  spr8(55, lcx(172),lcy(211), 1,1,0, 0)
  spr8(56, lcx(173),lcy(211), 1,1,0, 0)

  --塔を置く
  spr8(17, lcx(165),lcy(209), 1,1,0, 0)
  spr8(25, lcx(165),lcy(210), 1,1,0, 0)

  --橋を置く
  spr8(22, lcx(168),lcy(204), 1,1,0, 0)

  -- HPMP=1
  --   win(wstat, 0,   0, 1, 2, 3, HPMP,"ああああ")
  --   win(wstat, 40,  0, 1, 2, 3, HPMP,"いいいい")
  --   win(wstat, 80,  0, 1, 2, 3, HPMP,"うううう")
  --   win(wstat, 120, 0, 1, 2, 3, HPMP,"ええええ")
  --   rectfill(56, 32, 48, 90, 0, "/world/png/enemy/3.png") --160,48が敵エリアの最大値
  --   win(wstat, 0,80,1, 4,18, 0,"むらびと")
end