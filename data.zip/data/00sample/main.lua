x=64
y=60
cn = 0

function setup()
  fillrect(20,20,8,8,7)
end

function _init()--1回だけ
  -- music(2,64,60,0,3)
  -- music(2,64,130,4,7)--musicNo, Volume0-255,tempo slow140 ~ high60 loopstart,loopend
  -- fps(30)
    setup()
end

function input()

  if btn(1) >= 1 then x = x-3 end
  if btn(2) >= 1 then x = x+3 end
  if btn(3) >= 1 then 
    y = y-3
    if y<0 then y = 128 end
  end
  if btn(4) >= 1 then y = y+3 end

  if btn(3) >= 1 then 
    cn = cn + 1
   end
  
end

function _update()--ループします
  input()
end

function _draw()--ループします
  -- cls(0)
  -- cls(1)
  for j = 0,15 do
    for i = 0,15 do
      -- fillrect(i*8,j*8,7,7,i*8,0,j*8) 
      if cn%3 == 0 then 
        fillrect(i*8,j*8,8,8,0,i*8,j*8) 
      elseif cn%3 == 1 then 
        fillrect(i*8,j*8,8,8,i*8,j*8,0) 
      elseif cn%3 == 2 then 
        fillrect(i*8,j*8,8,8,i*8,0,j*8) 
      end
    end
  end

  
  fillrect(x,y,8,8,10)
  -- fillrect(x,y,size,size,8)
  spr8(1,x,y)
end








  