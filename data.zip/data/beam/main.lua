-- pc={}
-- pc.x=64
-- pc.y=64
-- pc.s=4 -- sprite
-- pc.d=4 -- direction
-- pc.dx=0 -- direction x
-- pc.dy=1 -- direction y
-- pc.spd=2
-- pc.walking=false
-- pc.gun=false
-- pc.gun_interval=0
-- max_gun_interval=8

-- ipf=8 -- interval per frame
-- nf=2 -- number of frames
-- t=0

-- beams={}
-- beam_spd=4
-- beam_len=4
-- beam_life=64

-- --- beams
-- function update_beam(b)
--   b.x = b.x + b.dx * beam_spd
--   b.y = b.y + b.dy * beam_spd
--   b.life = b.life - 1
--   if b.life <= 0 then
--     del(beam, b)
--   end
-- end

-- function draw_beam(b)
--   line(b.x + b.dx * beam_len, b.y + b.dy * beam_len, b.x, b.y, 8)
-- end

-- function input()
--   pc.walking = false
--   if btn(0) then
--     pc.dx = -1
--     pc.dy = 0
--     pc.d = 1
--     pc.walking = true
--   end
--   if btn(1) then
--     pc.dx = 1
--     pc.dy = 0
--     pc.d = 2
--     pc.walking = true
--   end
--   if btn(2) then
--     pc.dx = 0
--     pc.dy = -1
--     pc.d = 3
--     pc.walking = true
--   end
--   if btn(3) then
--     pc.dx = 0
--     pc.dy = 1
--     pc.d = 4
--     pc.walking = true
--   end
--   pc.gun = btn(4)
--   if pc.gun and pc.gun_interval == 0 then
--     local bx = pc.x
--     local by = pc.y
--     if pc.d == 1 then
--       bx = bx - 3
--       by = by + 1
--     elseif pc.d == 2 then
--       bx = bx + 2
--       by = by + 1
--     elseif pc.d == 3 then
--       bx = bx + 2
--       by = by - 2
--     else
--       bx = bx - 3
--     end
--     add_beam(bx, by, pc.dx, pc.dy)
--     pc.gun_interval = max_gun_interval
--   end
-- end

-- function draw_pc()
--   pc.s = pc.d
--   if pc.walking then
--     pc.s = pc.s + flr((t % (nf * ipf)) / ipf + 1) * 16
--   end
--   if pc.gun then
--     pc.s = pc.s + 4
--   end
--   spr(pc.s, pc.x - 4, pc.y - 4)
-- end

-- function update_pc()
--   if pc.walking then
--     pc.x = pc.x + pc.dx * pc.spd
--     pc.y = pc.y + pc.dy * pc.spd
--   end
--   if pc.gun_interval > 0 then
--     pc.gun_interval = pc.gun_interval - 1
--   end
-- end

-- function _update()
--   t = t + 1
--   input()
--   update_pc()
--   foreach(beams, update_beam)
-- end

-- function _draw()
--   rectfill(0, 0, 127, 127, 13)
--   draw_pc()
--   foreach(beams, draw_beam)
-- end
---------------------------------------------------


pc={}
ipf=8 -- interval per frame 
nf=2 -- number of frames 
t=0

beams={}
beam_spd=4
beam_len=4
beam_life=64

function add_beam(x, y, dx, dy)
 local b={}
 b[1].x=x
 b[1].y=y
 b[1].dx=dx
 b[1].dy=dy
 b[1].life=beam_life
 beams[#beams + 1] = b[1]--addと同じ
end

function update_beam(b)
  b[1].x = b[1].x + b[1].dx*beam_spd
  b[1].y = b[1].y + b.dy*beam_spd
  b[1].life = b[1].life - 1

  -- if b.life<=0 then del(beam, b) end end function draw_beam(b) line(b.x+b.dx*beam_len, b.y+b.dy*beam_len, b.x, b.y, 8) end
  --    pc.gun_interval-=1
  -- end
 end

function input()
 pc[1].dx=0
 pc[1].dy=0
 pc[1].walking=false
 if btnp(1) then
  pc[1].dx=pc[1].dx-1
  pc[1].d=1
  pc[1].walking=true
 end
 if btnp(2) then
  pc[1].dx=pc[1].dx+1
  pc[1].d=2
  pc[1].walking=true
 end
 if btnp(3) then
  pc[1].dy=pc[1].dy-1
  pc[1].d=3
  pc[1].walking=true
 end
 if btnp(4) then
  pc[1].dy=pc[1].dy+1
  pc[1].d=4
  pc[1].walking=true
 end
 pc[1].gun=btnp(4)

--  add_beam(bx, by, pc[1].dx, pc[1].dy)
end

function draw_pc()
  pc[1].s=64+pc[1].d
  if pc[1].walking then
   pc[1].s=pc[1].s+flr((t%(nf*ipf))/ipf+1)*8
  end
  if pc[1].gun then
   pc[1].s=pc[1].s+4
  end
  -- spr(pc[1].s,pc[1].x-4,pc[1].y-4)
  spr8(pc[1].s,pc[1].x-4,pc[1].y-4, 1,1,0, 0,1)
end

function update_pc()
  pc[1].x=pc[1].x+pc[1].dx*pc[1].spd
  pc[1].y=pc[1].y+pc[1].dy*pc[1].spd
end

function _init()
  pc[1] = {
    x=64,
    y=64,
    s=1, -- sprite
    d=1, -- direction
    dx=0, -- direction x 
    dy=0, -- direction y 
    spd=2,
    walking=false,
    gun=false
  }
end

function _update()
 t=t+1
 input()
 update_pc()
end

function _draw()
  cls(0)
--  rectfill(0,0,127,127,13)
 draw_pc()
end
----------------------------------------------------
-- ix=32 -- アイテムのX座標
-- iy=32-- アイテムのY座標
-- is=5 -- アイテムのスプライト番号

-- -- function warp_item()
-- --   ix=flr(rnd(160))
-- --   iy=flr(rnd(128))
-- -- end

-- function distance(x1,y1,x2,y2)
--   return sqrt((x1-x2)^2+(y1-y2)^2)
--  end

--  function collision(x1,y1,x2,y2)
--   if distance(x1,y1,x2,y2) < 6 then
--    return true
--   else
--    return false
--   end
--  end

-- x=80
-- y=64
-- prex = 0
-- prey = 0
-- v = 4

-- s=1 -- スプライト番号
-- d=1 -- 方向を示す                                                                                  
-- ipf=8 -- アニメーション1フレームについての時間(1ipf = 1/30秒)
-- nf=2 -- アニメーションするフレーム数(足踏みは2フレーム)
-- t=0

-- items={}

-- function draw_items()
--   for i = 1, #items do
--     local item = items[i]
--     spr8(9, item.x, item.y, 1, 1, 0, 0)
--   end
-- end

-- function update_pc()
--   pc.x=pc.x + pc.dx*pc.spd
--   pc.y=pc.y + pc.dy*pc.spd
-- end


-- function draw_pc()
--   pc.s=pc.d
--   if pc.walking then
--   --  pc.s+=flr((t%(nf*ipf))/ipf+1)*8
--    pc.s = pc.s + d+flr((t%(nf*ipf))/ipf+1)*8
--   end
--   if pc.gun then
--    pc.s = pc.s+4
--   end
--   -- spr(pc.s,pc.x-4,pc.y-4)
--   spr8(pc.s,pc.x-4,pc.y-4, 1,1,0, 0,1)
-- end


-- function _init()--1回だけ
--   local i = 1
--   for y = 0, 120, 8 do
--     for x = 0, 120, 8 do
--       items[i] = {x = x, y = y}
--       i = i + 1
--     end
--   end
-- end

-- function input()
--   local pressed=false
--   if btnp(1) then
--   -- sound=0
--    x = x-v
--    d=1
--    pressed=true
--   end
--   if btnp(2) then
--   -- sound=1
--     x = x+v
--    d=2
--    pressed=true
--   end
--   if btnp(3) then
--   -- sound=2
--    y = y-v
--    d=3
--    pressed=true
--   end
--   if btnp(4) then
--   -- sound=3
--    y = y+v
--    d=4
--    pressed=true
--   end

--   if pressed then
--    s=d+flr((t%(nf*ipf))/ipf+1)*8 --8個先が次のコマ
--   else
--    s=d
--   end
  
--  end

-- function _update()
--   input()
--   update_pc()
-- end

-- function _draw()
--   cls(0)
--   -- draw_items()
--   -- for i = #items, 1, -1 do
--   --   if collision(x, y, items[i].x, items[i].y) == true then
--   --     items[i].x = 136
--   --     items[i].y = 0
--   --   end
--   -- end

--   draw_pc()

--   -- spr8(s+64, x-4,y-4, 1,1,0, 0,1)
--   -- spr8(s+64,x,y,1,1,0, 0,10)--主人公スプライト透明色指定のあとに色番号をつけるとふちどり

--   text(get_map_sprn(tx,ty),120,96)--スプライト値を表示

-- -- spr8(8,tx,ty,1,1,0, 0,10)--向いている方向の座標（スプライトを表示するとマップ情報が描き変わってしまうので最後に表示）
-- end

