-- x=64 -- プレイヤーのX座標
-- y=64 -- プレイヤーのY座標
-- s=1 -- プレイヤーのスプライト番号
-- d=1 -- 方向を示す                                            
-- ipf=8 -- アニメーション1フレームについての時間(1ipf = 1/30秒)
-- nf=2 -- アニメーションするフレーム数(足踏みは2フレーム)

-- ix=32 -- アイテムのX座標
-- iy=32-- アイテムのY座標
-- is=5 -- アイテムのスプライト番号

-- t=0

-- function distance(x1,y1,x2,y2)
--  return sqrt((x1-x2)^2+(y1-y2)^2)
-- end

-- function collision(x1,y1,x2,y2)
--  if distance(x1,y1,x2,y2) < 4 then
--   return true
--  else
--   return false
--  end
-- end

-- function warp_item()
--  ix=rnd(160)
--  iy=rnd(128)
-- end

-- function input()
--  local pressed=false
--  if btnp(1) then
--   x = x-1
--   d=1
--   pressed=true
--  end
--  if btnp(2) then 
--   x = x+1 
--   d=2
--   pressed=true
--  end
--  if btnp(3) then 
--   y = y-1 
--   d=3
--   pressed=true
--  end
--  if btnp(4) then 
--   y = y+1 
--   d=4
--   pressed=true
--  end
--  if pressed then
--   s=d+flr((t%(nf*ipf))/ipf+1)*8 --8個先が次のコマ
--  else
--   s=d
--  end
-- end

-- function _init()
--   t = t+1
--   input()
-- end

-- function _update()

--  if collision(x,y,ix,iy) then
--   warp_item()
--   -- sfx(0)
--  end
-- end

-- function _draw()
-- --  rectfill(0,0,127,127,13)
--  spr8(is,ix-4,iy-4, 1,1,0,0)
--  spr8(s,x-4,y-4, 1,1,0, 0)
-- end

----------------------------------------------------
ix=32 -- アイテムのX座標
iy=32-- アイテムのY座標
is=5 -- アイテムのスプライト番号

-- function warp_item()
--   ix=flr(rnd(160))
--   iy=flr(rnd(128))
-- end

function distance(x1,y1,x2,y2)
  return sqrt((x1-x2)^2+(y1-y2)^2)
 end

 function collision(x1,y1,x2,y2)
  if distance(x1,y1,x2,y2) < 6 then
   return true
  else
   return false
  end
 end

x=80
y=64
prex = 0
prey = 0
v = 4

s=1 -- スプライト番号
d=1 -- 方向を示す                                                                                  
ipf=8 -- アニメーション1フレームについての時間(1ipf = 1/30秒)
nf=2 -- アニメーションするフレーム数(足踏みは2フレーム)
t=0

items={}

function draw_items()
  for i = 1, #items do
    local item = items[i]
    spr8(9, item.x, item.y, 1, 1, 0, 0)
  end
end
 

function _init()--1回だけ
  local i = 1
  for y = 0, 120, 8 do
    for x = 0, 120, 8 do
      items[i] = {x = x, y = y}
      i = i + 1
    end
  end
end

function input()
  local pressed=false
  if btnp(1) then
  -- sound=0
   x = x-v
   d=1
   pressed=true
  end
  if btnp(2) then
  -- sound=1
    x = x+v
   d=2
   pressed=true
  end
  if btnp(3) then
  -- sound=2
   y = y-v
   d=3
   pressed=true
  end
  if btnp(4) then
  -- sound=3
   y = y+v
   d=4
   pressed=true
  end

  if pressed then
   s=d+flr((t%(nf*ipf))/ipf+1)*8 --8個先が次のコマ
  else
   s=d
  end

 end

function _update()
  input()
end

function _draw()
  cls(0)

  draw_items()

  -- local i = #items
  for i = #items, 1, -1 do
    if collision(x, y, items[i].x, items[i].y) == true then
      items[i].x = 136
      items[i].y = 0
    end
    
  end

  spr8(s+64, x-4,y-4, 1,1,0, 0,1)
  -- spr8(s+64,x,y,1,1,0, 0,10)--主人公スプライト透明色指定のあとに色番号をつけるとふちどり

  text(get_map_sprn(tx,ty),120,96)--スプライト値を表示

-- spr8(8,tx,ty,1,1,0, 0,10)--向いている方向の座標（スプライトを表示するとマップ情報が描き変わってしまうので最後に表示）
end
