-- タイトルと説明
local title = "PIN CLIMB"
local description = "[Hold] Stretch"

-- 定数
local CHARACTER_HEIGHT = 6
local CHARACTER_WIDTH = 6

-- キャラクター（ここは定義のためにありますが、Luaでは通常の配列として扱います）
local characters = {{
    "      ",
    "      ",
    "      ",
    "      ",
    "      ",
    "      ",
}}
local charactersCount = 1

-- ゲームの状態を保持する変数
local cord
local PIN_CLIMB_MAX_PIN_COUNT = 32
local pins = {}
local pinIndex = 1
local nextPinDist
local cordLength = 7
local ticks = 0
local difficulty = 1
local input = {isJustPressed = false, isPressed = false}
local score = 0

initState = 0
playState = 1
overState = 2
GameState = initState

-- Pin 構造体とそのコンストラクタ
local Pin = {}

-- Pin クラスのメソッドを定義
Pin.__index = Pin

function Pin:new(x, y)
    local obj = {
        pos = {x = x, y = y}, -- ピンの位置
        isAlive = true -- ピンが有効かどうかのフラグ
    }
    
    -- 手動でメソッドを設定
    for k, v in pairs(Pin) do
        if type(v) == "function" then
            obj[k] = v
        end
    end
    
    return obj
end

-- Cord 構造体とそのコンストラクタ
local Cord = {}
Cord.__index = Cord

function Cord:new(pin)
    local obj = {
        angle = 0, -- コードの初期角度
        length = 7, -- コードの初期長さ
        pin = pin -- コードが接続されるピン
    }
    setmetatable(obj, self)
    return obj
end

-- 新しいピンをゲームに追加する関数
local function addPin(x, y)
  local pin = Pin:new(x, y)
  pins[pinIndex] = pin
  -- ピンのインデックスを循環させて配列を再利用する
  pinIndex = (pinIndex % PIN_CLIMB_MAX_PIN_COUNT) + 1
end


function init()
  gini(title, description, characters, charactersCount)

  -- box(no, isAlive)

  -- Vector pos;
  -- float yAngle;
  -- float vx;
  -- float ticks;
  -- bool isAlive;

end

function over()
  color(8)
  text("game over", 16, 42)
  color(7)
  text("restart[9]", 80, 42)
  if btnp(9) then
      GameState = initState
  end
end

function play()
  cls(3)
  text(ticks,0,16)
  
  if ticks == 0 then
    -- ゲーム開始時に状態を初期化
    pins = {}
    pinIndex = 1
    -- addPin(50, 5) -- 最初のピンを追加
    nextPinDist = 5
    -- cord = Cord:new(pins[1]) -- コードを最初のピンに接続
  end

  -- 難易度に基づくスクロール速度
  -- local scr = difficulty * 0.02
  -- if cord.pin.pos.y < 80 then
  --     scr = scr + (80 - cord.pin.pos.y) * 0.1
  -- end

  -- -- 入力をチェックしてコードを伸ばす
  -- if input.isJustPressed then
  --     -- play(SELECT) -- 選択音を再生
  -- end

  -- if input.isPressed then
  --     cord.length = cord.length + difficulty
  -- else
  --     cord.length = cord.length + (cordLength - cord.length) * 0.1
  -- end

  -- -- コードの角度を更新
  -- cord.angle = cord.angle + difficulty * 0.05
  -- -- bar(cord.pin.pos.x, cord.pin.pos.y, cord.length, cord.angle) -- コードを描画

  -- if cord.pin.pos.y > 98 then
  --     -- play(EXPLOSION) -- 爆発音を再生
  --     -- gameOver() -- ゲームオーバー
  -- end

  -- local nextPin = nil
  -- -- ピンを更新し、衝突をチェック
  -- for i, p in ipairs(pins) do
  --     if p.isAlive then
  --         p.pos.y = p.pos.y + scr
  --         -- プレイヤー（コード）との衝突をチェック
  --         if box(p.pos.x, p.pos.y, 3, 3).isColliding.rect[BLACK] and p ~= cord.pin then
  --           nextPin = p
  --         end
  --         p.isAlive = p.pos.y <= 102
  --     end
  -- end

  -- 次のピンとの衝突を処理
  -- if nextPin then
  --     -- play(POWER_UP) -- パワーアップ音を再生
  --     -- addScore(math.ceil(distanceTo(cord.pin.pos, nextPin.pos)), nextPin.pos) -- スコアを追加
  --     cord.pin = nextPin
  --     cord.length = cordLength
  -- end

  -- -- 新しいピンの生成を処理
  -- nextPinDist = nextPinDist - scr
  -- while nextPinDist < 0 do
  --     addPin(math.random(10, 90), -2 - nextPinDist)
  --     nextPinDist = nextPinDist + math.random(5, 15)
  -- end

  ticks = ticks + 1

end

function setup()

end

function _init()--1回だけ
    setup()
    GameState = playState
end

function input()

end

function _update()--ループします
  input()
end

function _draw()--ループします
  -- fillrect(tp(0),tp(1),8,8,10)

  if GameState == initState then
    init()
  elseif GameState == playState then
    play()
  elseif GameState == overState then
    over()
  end
end