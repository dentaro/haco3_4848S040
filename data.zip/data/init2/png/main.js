setup = function(){
}

loop = function(){
    bg(0,0,"/init/logo.png");
}
